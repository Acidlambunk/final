let selectedRole = "";

        // Function to handle role selection
        function selectRole(role) {
            selectedRole = role;
            console.log("Selected Role:", selectedRole); // Log selected role
            document.getElementById("question1").classList.add("hidden"); // Hide question 1
            document.getElementById("question2").classList.remove("hidden"); // Show question 2
        }

        // Function to ask for the user's name
        function askNextQuestion() {
            const name = document.getElementById("nameInput").value.trim();
            if (!name) {
                alert("Please enter your name."); // Alert if name is empty
                return;
            }
            console.log("Entered Name:", name); // Log entered name

            document.getElementById("question2").classList.add("hidden"); // Hide question 2

            // Show next question based on selected role
            if (selectedRole === "student") {
                document.getElementById("question3").classList.remove("hidden"); // Show question 3
            } else if (selectedRole === "tutor") {
                document.getElementById("question5").classList.remove("hidden"); // Show question 5
            } else if (selectedRole === "teacher") {
                document.getElementById("question6").classList.remove("hidden"); // Show question 6
            }
        }

        // Function for student to select subjects
        function nextStudentQuestion() {
            const subjects = document.querySelectorAll("input[name='studentSubjects']:checked");
            if (subjects.length === 0) {
                alert("Please select at least one subject."); // Alert if no subjects selected
                return;
            }

            // Log selected subjects
            const selectedSubjects = Array.from(subjects).map(input => input.value);
            console.log("Selected Subjects (Student):", selectedSubjects);

            document.getElementById("question3").classList.add("hidden"); // Hide question 3
            document.getElementById("question4").classList.remove("hidden"); // Show question 4
        }

        // Function to redirect student based on selection
        function redirectStudent(option) {
            console.log("Student Option Selected:", option); // Log option selected by student
            if (option === "tutor") {
                window.location.href = "student-tutor-dashboard.html"; // Redirect to tutor dashboard
            } else if (option === "teacher") {
                window.location.href = "student-teacher-dashboard.html"; // Redirect to teacher dashboard
            } else if (option === "both") {
                window.location.href = "student-both-dashboard.html"; // Redirect to both dashboard
            }
        }

        // Function for tutor to input years of experience
        function nextTutorQuestion() {
            const experience = document.getElementById("tutoringExperience").value;
            if (!experience || experience < 1) {
                alert("Please enter a valid number of years."); // Alert if invalid experience
                return;
            }
            console.log("Years of Tutoring Experience:", experience); // Log tutoring experience
            document.getElementById("question5").classList.add("hidden"); // Hide question 5
            document.getElementById("question7").classList.remove("hidden"); // Show question 7
        }

        // Function for teacher to input teaching location
        function nextTeacherQuestion() {
            const location = document.getElementById("teachingLocation").value.trim();
            if (!location) {
                alert("Please enter your teaching location."); // Alert if location is empty
                return;
            }
            console.log("Teaching Location:", location); // Log teaching location
            document.getElementById("question6").classList.add("hidden"); // Hide question 6
            document.getElementById("question7").classList.remove("hidden"); // Show question 7
        }

        // Function to redirect based on role and selected subjects
        function redirectBasedOnRole() {
            const subjects = document.querySelectorAll("input[name='teachSubjects']:checked");
            if (subjects.length === 0) {
                alert("Please select at least one subject."); // Alert if no subjects selected
                return;
            }

            // Log selected subjects for teaching
            const selectedTeachSubjects = Array.from(subjects).map(input => input.value);
            console.log("Selected Subjects (Teacher/Tutor):", selectedTeachSubjects);

            if (selectedRole === "tutor") {
                window.location.href = "tutor-dashboard.html"; // Redirect to tutor dashboard
            } else if (selectedRole === "teacher") {
                window.location.href = "teacher-dashboard.html"; // Redirect to teacher dashboard
            }
        }